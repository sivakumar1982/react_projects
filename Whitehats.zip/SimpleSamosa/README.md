

Team Name: SimpleSamosa

Team Members:
Naga Mano Ranjita cherukupalli
Rachamallu Maheswar reddy
Mynampati Harivenkata Lakshmi Kumar
Suman Pasupula
Ravula Shilpa