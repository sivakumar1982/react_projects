import React, { Component } from 'react';
;
class jobdetails extends Component {
    
    render() {
        console.log();
        return (
        <div>
          <table>   
            <thead>
              <th>
                <td>JobDetails</td>
                <td>Description</td>
                <td>Location</td>
                <td>Open Date</td>
              </th>
            </thead>
         </table>
        </div>
    );
  }
}
export default jobdetails;
