import React, { Component } from "react";
 
class Contact extends Component {
  render() {
    return (
      <div>
        <h2>GOT QUESTIONS?</h2>
        <p>Contact Verizon Support <a href="https://www.verizon.com/support/residential/contact-us/homepage.htm">forums</a>.
        </p>
      </div>
    );
  }
}
 
export default Contact;