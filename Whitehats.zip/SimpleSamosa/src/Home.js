import React, { Component } from "react";
 
class Home extends Component {
  render() {
    return (
      <div>
        <h2>HELLO</h2>
        <p>Our mission: Verizon delivers the promise of the digital world by enhancing the ability of humans,
            businesses and society to do more new and do more good</p>
 
        <p>Our first commercial launch is planned to be in Sacramento. Details of that launch, 
            and the announcement of additional markets,
             will be provided in the second half of 2018.</p>
      </div>
    );
  }
}
export default Home;