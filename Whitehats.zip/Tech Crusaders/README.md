# Tech Crusaders - Job Portal React App

### Team Members
  - Naresh, Surisetty
  - Devaraj, Subramani
  - Mohanapriya, Somasundharam

### Live Preview
* [Live Preview](https://reactathon-techcrusaders.herokuapp.com)