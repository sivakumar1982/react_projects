import React from 'react';

const Error = ({ error }) => <p>{error.message}</p>

export default Error;