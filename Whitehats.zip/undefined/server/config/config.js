module.exports = {
    //MongoDB configuration
    production: {
        db: 'mongodb://admin:admin123@ds125381.mlab.com:25381/vzhackathon',
        app: {
            name: 'graphql'
        }
    }
};