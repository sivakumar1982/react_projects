# Spartans

# Contributors
  1. Dyana Jesurathi 
  2. Anup Raj

# Topic 
  Gamification Portal

# Idea of Approach 
 Portal consist of following modules
   1. User Dashboard - Recent Activities, TODO, Badge, Search
   2. Manager Dashboard - Reporting User, Overall Ranking
   3. Events - Upcoming Events, Participants, History of Events, Achievments (Top Score)
   4. Training - Choose language, then list all training links, future (it should be dynamic training like secure code warrior)
   5. Reports  - Org Level, DH level, Mgr Level
   6. Search - General Search
   
# Services
   1. Rest Services http://localhost:3000
   2. GUI - http://localhost:4000/
   
# Tech Stack
   1. MongoDB
   2. MongoDB Compass
   3. GraphQL Express Server
   4. Mongoose
   5. React JS
   
# What is done
   
 
