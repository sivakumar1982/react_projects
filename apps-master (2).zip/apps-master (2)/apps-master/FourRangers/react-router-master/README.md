##Steps of running this project

from the command prompt clone the project

* $git clone https://github.com/techsithgit/react-router.git
* $cd react-router
* $npm install
* $npm start

[Watch the Tutorial](https://youtu.be/XRfD8xIOroA).
