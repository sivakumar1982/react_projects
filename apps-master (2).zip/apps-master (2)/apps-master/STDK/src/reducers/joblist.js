export default function () {
  return [{
    "job_name": "Java dev",
    "job_id": "123456789",
    "location": "chennai",
    "experience": "5",
    "skillset":"Java Spring Developer",
  },{
    "job_name": "UI dev",
    "job_id": "883292300348",
    "location": "hyd",
    "experience": "2",
    "skillset":"Angular and React JS developer"
  },{
    "job_name": "PeopleSoft",
    "job_id": "8743847638473",
    "location": "chennai",
    "experience": "3",
    "skillset":"PeopleSoft admin"
  },{
    "job_name": "React",
    "job_id": "0988765553",
    "location": "chennai",
    "experience": "6",
    "skillset":"React Js"
  }];
}
