import React from 'react';
import { Component } from 'react'

import {
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  Button,
  ButtonGroup,
  Form,
  FormGroup,
  Label,
  Input,
  FormText,
  FormFeedback,
} from 'reactstrap';

import Page from 'components/Page';

class StepThree extends Component {
 render(){
    return (
        <Page title="Finish and Launch your event?">        
        </Page>
      );
    }; 
}

export default StepThree;
