import React from "react";
import ReactDOM from 'react-dom';
import { Carousel, Row, Col, Navbar, Nav, NavItem } from 'react-bootstrap';

export default () => (
  <ListGroup>
    <ListGroupItem>Item 1</ListGroupItem>
    <ListGroupItem>Item 2</ListGroupItem>
    <ListGroupItem>...</ListGroupItem>
  </ListGroup>
  
);
