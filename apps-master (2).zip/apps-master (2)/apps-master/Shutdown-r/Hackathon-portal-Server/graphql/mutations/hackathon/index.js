var addHackathon = require('./add').add;
var removeHackathon = require('./remove').remove;
var updateHackathon = require('./update').update;

module.exports = {
  addHackathon,
  removeHackathon,
  updateHackathon
}