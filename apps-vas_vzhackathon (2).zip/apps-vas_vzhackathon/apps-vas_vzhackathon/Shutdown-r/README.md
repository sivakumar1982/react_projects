#shutdown /r

## Get started
*Development*
```
git clone https://github.com/reactathon2018/apps.git
npm install
npm start
```

*Build*
```
npm run build
```