# mongodb-graphql-simple-server

[Demo](https://mongodb-graphql-server-template-jniwoocpmv.now.sh/graphiql)
