module.exports = {
  extends: ['prettier-standard/lib/base', 'prettier'],
  plugins: ['import'],
}
