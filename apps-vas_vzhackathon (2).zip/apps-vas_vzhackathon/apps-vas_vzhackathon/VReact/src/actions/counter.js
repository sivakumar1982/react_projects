import { ADD_COUNTER } from './types';

export function addCount() {
    return {type: ADD_COUNTER};
}
