import React from 'react';
import HackatonListContainer from '../../Hackatons/container/HackatonListContainer'

export default class Home extends React.Component{
    render(){
        return (
            <div>
                <HackatonListContainer />
            </div>
        )
    }
}