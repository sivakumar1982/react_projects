import React from 'react';
import HackthonDetailView from '../components/HackthonDetailView';
export default class HackthonDetailViewContainer extends React.Component {
    render(){
        return (
            <div>
               <HackthonDetailView/>
            </div>
        )
    }
}