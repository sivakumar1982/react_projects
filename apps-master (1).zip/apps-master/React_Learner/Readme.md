React_Learners Reactathon -JobPoratal

Team Members
Vaddipalli Kiran Kumar

Chandk Niteesh

Chittepu Veerender

V Naveen Kumar 

Technolgy Stack

Spring-Boot

ReactJs

MongoDB

Swagger




