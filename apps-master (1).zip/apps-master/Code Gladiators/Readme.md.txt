Test for Code Gladiators
