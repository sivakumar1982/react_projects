'use strict';

module.exports = function(Teams) {

};
