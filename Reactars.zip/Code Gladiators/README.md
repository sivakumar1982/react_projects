# Code Gladiators - Hackathon Dashboard (Hackesia)

Readme to be done

## Team Members:

1. Bharatwaaj Shankar
2. Arun Kumar
3. Kaushik Nagarajan
4. Hari Santhosh

## Links:

+ [Live Preview](https://zwq3nk5olm.codesandbox.io)

## Quick start

- [Download from Github](https://github.com/reactathon2018/apps.git).
- Clone the repo: `git clone https://github.com/reactathon2018/apps.git`.

### What's included

TBD

