import admin from './admin/admin'

crudl.render(admin)
