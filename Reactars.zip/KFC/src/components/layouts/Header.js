import React, {Component} from 'react';

export default class Header extends Component {
    render() {
        var mystyle = {}
        return ( 
        <div>
            <center><h1 ><b><i>KFC CAREERS</i></b></h1></center>
        </div>    
        )
    }
}

