import React, { Component} from 'react';

export class About extends Component {
    render(){
        return (
            <div>All about KFC Careers</div>
        )
    }
}
