import React, {Component} from 'react';

export default class Footer extends Component {
    render() {
        return ( 
        <div>
            <center><h4><b>Contact us at careers@kfc.com </b></h4></center> 
        </div>
        )
    }
}

