import React, { Component} from 'react';
import PropTypes from 'prop-types';

export class NewsItemDetail extends Component {
    render(){
        return (
            <div>
                <h2>News story title</h2>
                <p>Body: test mad owl story text </p>
            </div>
        )
    }
}

// export default NewsItemDetail